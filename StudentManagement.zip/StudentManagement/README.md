# StudentManagement

ASP.NET Core MVC (.NET 6) sample project with CRUD for Student entity using SQLite.
DB file (StudentDB.db) is created automatically on first run.

## How to run

1. Open `StudentManagement.csproj` in Visual Studio 2022.
2. Restore NuGet packages.
3. Build and Run (F5). The app will auto-apply migrations and create `StudentDB.db`.
4. Navigate to `/Students`.

## Notes

- Project uses SQLite and includes migration files; no manual migration commands required.
